-- TikTokUI (StarterPlayerScripts или StarterGui > ScreenGui > LocalScript)
-- Отображает подарки, сообщения и уведомления на экране

local Players           = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService      = game:GetService("TweenService")

local player    = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- Ждём пока сервер создаст RemoteEvents
local remotes     = ReplicatedStorage:WaitForChild("TikTokRemotes", 10)
if not remotes then
    warn("[TikTokUI] TikTokRemotes не найден!")
    return
end

local GiftEvent   = remotes:WaitForChild("OnGift")
local ChatEvent   = remotes:WaitForChild("OnChat")
local LikeEvent   = remotes:WaitForChild("OnLike")
local MemberEvent = remotes:WaitForChild("OnMember")
local FollowEvent = remotes:WaitForChild("OnFollow")
local ViewerEvent = remotes:WaitForChild("OnViewers")

-- ─── Создание GUI ────────────────────────────────────────────────────────────
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "TikTokUI"
screenGui.ResetOnSpawn = false
screenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
screenGui.Parent = playerGui

-- Лента чата (левая сторона внизу)
local chatFeed = Instance.new("Frame")
chatFeed.Name = "ChatFeed"
chatFeed.Size = UDim2.new(0, 320, 0, 300)
chatFeed.Position = UDim2.new(0, 10, 1, -320)
chatFeed.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
chatFeed.BackgroundTransparency = 0.45
chatFeed.BorderSizePixel = 0
chatFeed.Parent = screenGui

local uiCornerChat = Instance.new("UICorner")
uiCornerChat.CornerRadius = UDim.new(0, 12)
uiCornerChat.Parent = chatFeed

local chatList = Instance.new("UIListLayout")
chatList.SortOrder = Enum.SortOrder.LayoutOrder
chatList.VerticalAlignment = Enum.VerticalAlignment.Bottom
chatList.Padding = UDim.new(0, 2)
chatList.Parent = chatFeed

local chatPadding = Instance.new("UIPadding")
chatPadding.PaddingLeft   = UDim.new(0, 8)
chatPadding.PaddingRight  = UDim.new(0, 8)
chatPadding.PaddingBottom = UDim.new(0, 8)
chatPadding.Parent = chatFeed

-- Зона уведомлений о подарках (правая сторона)
local giftZone = Instance.new("Frame")
giftZone.Name = "GiftZone"
giftZone.Size = UDim2.new(0, 280, 1, -20)
giftZone.Position = UDim2.new(1, -290, 0, 10)
giftZone.BackgroundTransparency = 1
giftZone.Parent = screenGui

local giftList = Instance.new("UIListLayout")
giftList.SortOrder = Enum.SortOrder.LayoutOrder
giftList.VerticalAlignment = Enum.VerticalAlignment.Bottom
giftList.Padding = UDim.new(0, 6)
giftList.Parent = giftZone

-- Счётчик зрителей
local viewerLabel = Instance.new("TextLabel")
viewerLabel.Size = UDim2.new(0, 140, 0, 32)
viewerLabel.Position = UDim2.new(0.5, -70, 0, 8)
viewerLabel.BackgroundColor3 = Color3.fromRGB(254, 44, 85)  -- TikTok red
viewerLabel.BackgroundTransparency = 0.1
viewerLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
viewerLabel.Font = Enum.Font.GothamBold
viewerLabel.TextSize = 14
viewerLabel.Text = "👁 -- зрителей"
viewerLabel.BorderSizePixel = 0
viewerLabel.Parent = screenGui

local vc = Instance.new("UICorner")
vc.CornerRadius = UDim.new(0, 16)
vc.Parent = viewerLabel

-- ─── Вспомогательные функции ─────────────────────────────────────────────────
local chatCount = 0

-- Добавить строку в ленту чата
local function addChatRow(icon, color, name, message)
    chatCount = chatCount + 1
    
    -- Удаляем старые сообщения если их слишком много
    local children = chatFeed:GetChildren()
    local rows = 0
    for _, c in ipairs(children) do
        if c:IsA("Frame") and c.Name == "ChatRow" then rows = rows + 1 end
    end
    if rows >= 8 then
        for _, c in ipairs(chatFeed:GetChildren()) do
            if c:IsA("Frame") and c.Name == "ChatRow" then
                c:Destroy()
                break
            end
        end
    end

    local row = Instance.new("Frame")
    row.Name = "ChatRow"
    row.Size = UDim2.new(1, 0, 0, 28)
    row.BackgroundTransparency = 1
    row.LayoutOrder = chatCount
    row.Parent = chatFeed

    local label = Instance.new("TextLabel")
    label.Size = UDim2.new(1, 0, 1, 0)
    label.BackgroundTransparency = 1
    label.TextColor3 = Color3.fromRGB(255, 255, 255)
    label.Font = Enum.Font.Gotham
    label.TextSize = 13
    label.TextXAlignment = Enum.TextXAlignment.Left
    label.TextWrapped = true
    label.RichText = true
    label.Text = string.format(
        '<font color="#%02x%02x%02x">%s <b>%s</b></font>: %s',
        math.floor(color.R*255), math.floor(color.G*255), math.floor(color.B*255),
        icon, name, message
    )
    label.Parent = row

    -- Анимация появления
    row.GroupTransparency = 1
    TweenService:Create(row, TweenInfo.new(0.25), {GroupTransparency = 0}):Play()
end

-- Показать уведомление о подарке
local function showGiftNotification(data)
    local card = Instance.new("Frame")
    card.Name = "GiftCard"
    card.Size = UDim2.new(1, 0, 0, 64)
    card.BackgroundColor3 = Color3.fromRGB(20, 20, 30)
    card.BackgroundTransparency = 0.1
    card.BorderSizePixel = 0
    card.LayoutOrder = os.clock() * 1000
    card.Parent = giftZone

    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 12)
    corner.Parent = card

    -- Полоска слева (TikTok стиль)
    local stripe = Instance.new("Frame")
    stripe.Size = UDim2.new(0, 4, 1, 0)
    stripe.BackgroundColor3 = Color3.fromRGB(254, 44, 85)
    stripe.BorderSizePixel = 0
    stripe.Parent = card
    local sc = Instance.new("UICorner")
    sc.CornerRadius = UDim.new(0, 4)
    sc.Parent = stripe

    -- Текст подарка
    local giftText = Instance.new("TextLabel")
    giftText.Size = UDim2.new(1, -16, 0.55, 0)
    giftText.Position = UDim2.new(0, 12, 0, 4)
    giftText.BackgroundTransparency = 1
    giftText.TextColor3 = Color3.fromRGB(255, 215, 0)  -- золотой
    giftText.Font = Enum.Font.GothamBold
    giftText.TextSize = 15
    giftText.TextXAlignment = Enum.TextXAlignment.Left
    giftText.Text = string.format("🎁 %s x%d", data.giftName, data.giftCount or 1)
    giftText.Parent = card

    -- Ник отправителя
    local nameText = Instance.new("TextLabel")
    nameText.Size = UDim2.new(1, -16, 0.4, 0)
    nameText.Position = UDim2.new(0, 12, 0.55, 0)
    nameText.BackgroundTransparency = 1
    nameText.TextColor3 = Color3.fromRGB(200, 200, 220)
    nameText.Font = Enum.Font.Gotham
    nameText.TextSize = 12
    nameText.TextXAlignment = Enum.TextXAlignment.Left
    nameText.Text = string.format("от %s • 💎 %d", data.nickname or data.username, data.totalDiamonds or 0)
    nameText.Parent = card

    -- Появление
    card.GroupTransparency = 1
    TweenService:Create(card, TweenInfo.new(0.3, Enum.EasingStyle.Back), {GroupTransparency = 0}):Play()

    -- Удаление через 5 секунд
    task.delay(5, function()
        if card and card.Parent then
            TweenService:Create(card, TweenInfo.new(0.4), {GroupTransparency = 1}):Play()
            task.wait(0.4)
            card:Destroy()
        end
    end)
end

-- ─── Обработка RemoteEvents ──────────────────────────────────────────────────

GiftEvent.OnClientEvent:Connect(function(data)
    showGiftNotification(data)
    addChatRow("🎁", Color3.fromRGB(255, 215, 0), data.nickname or data.username,
        string.format("подарил %s x%d!", data.giftName, data.giftCount or 1))
end)

ChatEvent.OnClientEvent:Connect(function(data)
    addChatRow("💬", Color3.fromRGB(100, 200, 255), data.nickname or data.username, data.message)
end)

MemberEvent.OnClientEvent:Connect(function(data)
    addChatRow("👁", Color3.fromRGB(150, 255, 150), data.nickname or data.username, "зашёл на трансляцию")
end)

FollowEvent.OnClientEvent:Connect(function(data)
    addChatRow("⭐", Color3.fromRGB(255, 100, 200), data.nickname or data.username, "подписался!")
end)

LikeEvent.OnClientEvent:Connect(function(data)
    addChatRow("❤️", Color3.fromRGB(255, 80, 80), data.nickname or data.username,
        string.format("поставил %d лайков", data.likeCount or 1))
end)

ViewerEvent.OnClientEvent:Connect(function(data)
    viewerLabel.Text = string.format("👁 %d зрителей", data.count or 0)
end)

print("[TikTokUI] Интерфейс TikTok загружен!")
