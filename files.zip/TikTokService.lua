-- TikTokService (ServerScriptService)
-- Опрашивает Node.js сервер и рассылает события клиентам

local HttpService    = game:GetService("HttpService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players        = game:GetService("Players")
local RunService     = game:GetService("RunService")

-- ─── Настройки ──────────────────────────────────────────────────────────────
-- Замените на IP вашего компьютера (или ngrok URL если нужен публичный доступ)
local SERVER_URL    = "http://127.0.0.1:3000"  -- ← ВСТАВЬТЕ ВАШ IP
local POLL_INTERVAL = 1.5  -- секунд между запросами

-- ─── RemoteEvents для клиентов ──────────────────────────────────────────────
local remotes = Instance.new("Folder")
remotes.Name = "TikTokRemotes"
remotes.Parent = ReplicatedStorage

local function makeRemote(name)
    local re = Instance.new("RemoteEvent")
    re.Name = name
    re.Parent = remotes
    return re
end

local GiftEvent   = makeRemote("OnGift")
local ChatEvent   = makeRemote("OnChat")
local LikeEvent   = makeRemote("OnLike")
local MemberEvent = makeRemote("OnMember")
local FollowEvent = makeRemote("OnFollow")
local ViewerEvent = makeRemote("OnViewers")

-- ─── Таблица обработчиков событий ──────────────────────────────────────────
local eventHandlers = {
    gift = function(data)
        print(string.format("🎁 [TikTok] %s подарил %s x%d (%d 💎)",
            data.nickname or data.username,
            data.giftName,
            data.giftCount or 1,
            data.totalDiamonds or 0
        ))
        -- Рассылаем всем игрокам
        GiftEvent:FireAllClients(data)
        
        -- Пример: дать монеты игроку с таким же ником (если он в игре)
        local player = Players:FindFirstChild(data.username)
        if player then
            local leaderstats = player:FindFirstChild("leaderstats")
            if leaderstats then
                local coins = leaderstats:FindFirstChild("Coins")
                if coins then
                    coins.Value = coins.Value + (data.giftCount or 1) * 10
                end
            end
        end
    end,

    chat = function(data)
        print(string.format("💬 [TikTok] %s: %s", data.nickname or data.username, data.message))
        ChatEvent:FireAllClients(data)
    end,

    like = function(data)
        LikeEvent:FireAllClients(data)
    end,

    member = function(data)
        print(string.format("👁 [TikTok] %s зашёл на трансляцию", data.nickname or data.username))
        MemberEvent:FireAllClients(data)
    end,

    follow = function(data)
        print(string.format("⭐ [TikTok] %s подписался!", data.nickname or data.username))
        FollowEvent:FireAllClients(data)
    end,

    viewers = function(data)
        ViewerEvent:FireAllClients(data)
    end,

    connected = function(data)
        print(string.format("✅ [TikTok] Подключён к @%s", data.username))
    end,

    disconnected = function(data)
        warn("[TikTok] Отключён от трансляции")
    end,

    error = function(data)
        warn("[TikTok] Ошибка: " .. (data.message or "unknown"))
    end,
}

-- ─── Основной цикл опроса ───────────────────────────────────────────────────
local function pollEvents()
    local ok, response = pcall(function()
        return HttpService:GetAsync(SERVER_URL .. "/events", true)
    end)

    if not ok then
        warn("[TikTok] Не удалось подключиться к серверу: " .. tostring(response))
        return
    end

    local decoded = HttpService:JSONDecode(response)
    if not decoded or not decoded.events then return end

    for _, event in ipairs(decoded.events) do
        local handler = eventHandlers[event.type]
        if handler then
            local s, err = pcall(handler, event.data)
            if not s then
                warn("[TikTok] Ошибка в обработчике " .. event.type .. ": " .. tostring(err))
            end
        end
    end
end

-- ─── Запуск ─────────────────────────────────────────────────────────────────
print("[TikTokService] Запущен. Опрашиваю: " .. SERVER_URL)

-- Включить HttpService в настройках игры! (Game Settings → Security → Allow HTTP Requests)
local elapsed = 0
RunService.Heartbeat:Connect(function(dt)
    elapsed = elapsed + dt
    if elapsed >= POLL_INTERVAL then
        elapsed = 0
        task.spawn(pollEvents)
    end
end)
